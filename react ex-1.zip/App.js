import React, { useState, useEffect, useRef } from "react";

const LOGIN_DETAILS = {
  username: "foo",
  password: "bar"
};

const USER_API_URL = "https://randomuser.me/api/?results=500";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [pageNumber, setPageNumber] = useState(1);
  const loaderRef = useRef(null);

  useEffect(() => {
    if (isLoggedIn) {
      fetch(`${USER_API_URL}&page=${pageNumber}`)
        .then((response) => response.json())
        .then((data) => {
          setUsers((prevUsers) => [...prevUsers, ...data.results]);
          setIsLoading(false);
        })
        .catch((error) => console.error(error));
    }
  }, [isLoggedIn, pageNumber]);

  useEffect(() => {
    if (!isLoggedIn) {
      return;
    }

    const options = {
      root: null,
      rootMargin: "20px",
      threshold: 1.0
    };

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        setPageNumber((prevPageNumber) => prevPageNumber + 1);
        setIsLoading(true);
      }
    }, options);

    if (loaderRef.current) {
      observer.observe(loaderRef.current);
    }

    return () => {
      if (loaderRef.current) {
        observer.unobserve(loaderRef.current);
      }
    };
  }, [isLoggedIn]);

  function handleLogin(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const username = formData.get("username");
    const password = formData.get("password");

    if (
      username === LOGIN_DETAILS.username &&
      password === LOGIN_DETAILS.password
    ) {
      setIsLoggedIn(true);
    } else {
      alert("Invalid username or password");
    }
  }

  function handleLogout() {
    setIsLoggedIn(false);
  }

  return (
    <div className="App">
      {isLoggedIn ? (
        <>
          <nav>
            <button onClick={handleLogout}>Logout</button>
          </nav>
          <ul>
            {users.map((user, index) => (
              <li key={index}>
                <img src={user.picture.thumbnail} alt={user.name.first} />
                <div>
                  <h2>
                    {user.name.first} {user.name.last}
                  </h2>
                  <p>{user.email}</p>
                </div>
              </li>
            ))}
          </ul>
          <div ref={loaderRef}>{isLoading && <p>Loading more users...</p>}</div>
        </>
      ) : (
        <form onSubmit={handleLogin}>
          <label>
            Username:
            <input type="text" name="username" />
          </label>
          <label>
            Password:
            <input type="password" name="password" />
          </label>
          <button type="submit">Login</button>
        </form>
      )}
    </div>
  );
}

export default App;
